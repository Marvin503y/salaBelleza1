
package modelo;

import com.mysql.cj.protocol.Resultset;
import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MINEDUCYT
 */
public class ProductosDAO {

    public static Productos MostrarProductos(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    Connection conexion;
    
    public ProductosDAO(){
        Conexion con = new Conexion();
        conexion = con.getConexion();
    
}
    public  List<Productos> listarProductos(){
        PreparedStatement ps;
        ResultSet rs;
        
        List<Productos> lista = new ArrayList<>();
        
        try{
            ps = conexion.prepareStatement("SELECT id, codigo, nombre, precio, existencias FROM productos");
            rs = ps.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("id");
                String codigo = rs.getString("codigo");
                String nombre = rs.getString("nombre");
                Double precio = rs.getDouble("precio");
                int existencias = rs.getInt("existencias");
                
                Productos productos = new Productos(id, codigo, nombre, precio, existencias);
                lista.add(productos);
            }
            return lista;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
    }
    }
    
     public  Productos mostrarProductos(int _id){
        PreparedStatement ps;
        ResultSet rs;
        Productos productos = null;
        
        try{
            ps = conexion.prepareStatement("SELECT id, codigo, nombre, precio, existencias FROM productos WHERE id=?");
            ps.setInt(1, _id);
            rs = ps.executeQuery();
            
            while(rs.next()){
                
                int id = rs.getInt("id");
                String codigo = rs.getString("codigo");
                String nombre = rs.getString("nombre");
                Double precio = rs.getDouble("precio");
                int existencias = rs.getInt("existencias");
                
                 productos = new Productos(id, codigo, nombre, precio, existencias);
            }
            return productos;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
    }
    }
     
     public  boolean insertar(Productos productos){
        PreparedStatement ps;
        
        try{
            ps = conexion.prepareStatement("INSERT INTO productos (codigo, nombre, precio, existencias) VALUES (?, ?, ?, ?)");
            ps.setString(1, productos.getCodigo());
            ps.setString(2, productos.getNombre());
            ps.setDouble(3, productos.getPrecio());
            ps.setInt(4, productos.getExistencias());
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
    }
    }
     
     public  boolean actualizar(Productos productos){
        PreparedStatement ps;
        
        try{
            ps = conexion.prepareStatement("UPDATE productos SET codigo=?, nombre=?, precio=?, existencias=? WHERE id=?");
            ps.setString(1, productos.getCodigo());
            ps.setString(2, productos.getNombre());
            ps.setDouble(3, productos.getPrecio());
            ps.setInt(4, productos.getExistencias());
            ps.setInt(5, productos.getId());
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
    }
    }
     
     public  boolean eliminar(int _id){
        PreparedStatement ps;
        
        try{
            ps = conexion.prepareStatement("DELETE FROM productos WHERE id=?");
            ps.setInt(1, _id);
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
    }
    }
}
