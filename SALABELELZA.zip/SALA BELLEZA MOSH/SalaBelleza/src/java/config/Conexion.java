
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MINEDUCYT
 */
public class Conexion {
    
    public Connection getConexion(){
        
        try{
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/sala_belleza_marvin?serverTimezone=UTC", "root", "marviN123oqueli");
            System.out.println("Conexion Existosa");
            return conexion;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return null ;
            
        }
    }
    
}
