
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Productos;
import modelo.ProductosDAO;

/**
 *
 * @author MINEDUCYT
 */
@WebServlet(name = "ProductosController", urlPatterns = {"/ProductosController"})
public class ProductosController extends HttpServlet{
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ProductosDAO ProductosDAO = new ProductosDAO();
        String accion;
        RequestDispatcher dispatcher = null;
        
        accion = request.getParameter("accion");
        
        if(accion == null || accion.isEmpty()){
            dispatcher = request.getRequestDispatcher("productos/index.jsp");
            List<Productos>listaProductos = ProductosDAO.listarProductos();
            request.setAttribute("lista", listaProductos);
        } else if("nuevo".equals(accion)){
            dispatcher = request.getRequestDispatcher("productos/nuevo.jsp");
        }
        else if("insertar".equals(accion)){
            
            String codigo = request.getParameter("codigo");
            String nombre = request.getParameter("nombre");
            Double precio = Double.parseDouble(request.getParameter("precio"));
            int existencias = Integer.parseInt(request.getParameter("existencias"));
            Productos productos = new Productos(0, codigo, nombre, precio, existencias);
            ProductosDAO.insertar(productos);
            dispatcher = request.getRequestDispatcher("productos/index.jsp");
            List<Productos>listaProductos = ProductosDAO.listarProductos();
            request.setAttribute("lista", listaProductos);
            
        } else if("modificar".equals(accion)){
           dispatcher = request.getRequestDispatcher("productos/modificar.jsp");
           int id = Integer.parseInt(request.getParameter("id"));
           Productos productos = ProductosDAO.mostrarProductos(id);
           request.setAttribute("productos", productos);
            
            
        }else if("actualizar".equals(accion)){
            int id = Integer.parseInt(request.getParameter("id"));
            String codigo = request.getParameter("codigo");
            String nombre = request.getParameter("nombre");
            Double precio = Double.parseDouble(request.getParameter("precio"));
            int existencias = Integer.parseInt(request.getParameter("existencias"));
            Productos productos = new Productos(id, codigo, nombre, precio, existencias);
            ProductosDAO.actualizar(productos);
            dispatcher = request.getRequestDispatcher("productos/index.jsp");
            List<Productos>listaProductos = ProductosDAO.listarProductos();
            request.setAttribute("lista", listaProductos);
        }
        
        else if("eliminar".equals(accion)){
            int id = Integer.parseInt(request.getParameter("id"));
            ProductosDAO.eliminar(id);
            dispatcher = request.getRequestDispatcher("productos/index.jsp");
            List<Productos>listaProductos = ProductosDAO.listarProductos();
            request.setAttribute("lista", listaProductos);
        } else{
            
            dispatcher = request.getRequestDispatcher("productos/index.jsp");
            List<Productos>listaProductos = ProductosDAO.listarProductos();
            request.setAttribute("lista", listaProductos);
            
        }
        dispatcher.forward(request, response);
        
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
